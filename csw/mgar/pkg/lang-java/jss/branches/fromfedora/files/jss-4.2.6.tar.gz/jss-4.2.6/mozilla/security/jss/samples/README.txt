Better sample code is available in the org/mozilla/jss/tests directory.
