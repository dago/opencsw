/*
 *	Spider
 *
 *	(c) Copyright 1989, Donald R. Woods and Sun Microsystems, Inc.
 *	(c) Copyright 1990, David Lemke and Network Computing Devices Inc.
 *
 *	See copyright.h for the terms of the copyright.
 *
 *	@(#)version.c	2.1	90/04/25
 *
 */
char	*version = "1.1" ;
char	*build_date = DATE;
char	*patch_level = "1";
